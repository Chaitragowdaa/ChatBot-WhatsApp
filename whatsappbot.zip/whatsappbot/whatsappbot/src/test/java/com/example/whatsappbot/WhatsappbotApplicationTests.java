package com.example.whatsappbot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WhatsappbotApplicationTests {

	@Test
	void contextLoads() {
	}

}

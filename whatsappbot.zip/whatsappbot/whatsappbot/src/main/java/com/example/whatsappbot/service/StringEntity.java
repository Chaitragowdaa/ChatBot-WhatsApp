package com.example.whatsappbot.service;

import java.nio.charset.Charset;

public class StringEntity {

    public StringEntity(String payload, Charset utf8) {
        
    }

}

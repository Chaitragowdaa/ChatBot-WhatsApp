package com.example.whatsappbot.controller;

import com.example.whatsappbot.service.WhatsAppService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/webhook")
public class WebhookController {

    private final WhatsAppService whatsAppService;

    public WebhookController(WhatsAppService whatsAppService) {
        this.whatsAppService = whatsAppService;
    }

    @Value("${verify.token}")
    private String verifyToken;

    @GetMapping
    public String verifyWebhook(
            @RequestParam(name = "hub.mode", required = false) String mode,
            @RequestParam(name = "hub.verify_token", required = false) String token,
            @RequestParam(name = "hub.challenge", required = false) String challenge
    ) {
        if ("subscribe".equals(mode) && verifyToken.equals(token)) {
            return challenge;
        }
        return "Verification failed";
    }

    @PostMapping
    public void receiveMessage(@RequestBody Map<String, Object> payload) {
        whatsAppService.processIncoming(payload);
    }
}
package com.example.whatsappbot.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.util.Map;

@Service
public class WhatsAppService {

    @Value("${whatsapp.phone.id}")
    private String phoneId;

    @Value("${whatsapp.access.token}")
    private String accessToken;

    private final ObjectMapper mapper = new ObjectMapper();

    public void processIncoming(Map<String, Object> body) {
        try {
            var entry = ((java.util.List<?>) body.get("entry")).get(0);
            var change = ((java.util.List<?>) ((Map<?, ?>) entry).get("changes")).get(0);
            Map<?, ?> value = (Map<?, ?>) ((Map<?, ?>) change).get("value");

            if (value.get("messages") != null) {
                var messages = (java.util.List<?>) value.get("messages");
                Map<?, ?> msg = (Map<?, ?>) messages.get(0);

                String from = msg.get("from").toString();
                String text = ((Map<?, ?>) msg.get("text")).get("body").toString();

                System.out.println("Incoming message: " + text + " from " + from);

                String reply = detectIntent(text);
                sendMessage(from, reply);
            }
        } catch (Exception e) {
            System.err.println("Error processing message: " + e.getMessage());
        }
    }

    private String detectIntent(String msg) {
        msg = msg.toLowerCase();
        if (msg.contains("hi") || msg.contains("hello")) {
            return "Hi! I’m Chaitra’s bot. Ask me about experience or technologies.";
        } else if (msg.contains("experience")) {
            return "I have experience in Java, Spring Boot, and web API development.";
        } else if (msg.contains("technologies")) {
            return "Technologies I know: Java, Spring Boot, Node.js, React, SQL.";
        } else {
            return "Sorry, I didn't understand that. Ask about experience or technologies.";
        }
    }

    private void sendMessage(String to, String text) {
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            String url = "https://graph.facebook.com/v22.0/" + phoneId + "/messages";
            HttpPost post = new HttpPost(url);

            post.setHeader("Authorization", "Bearer " + accessToken);
            post.setHeader("Content-Type", "application/json");

            String payload = mapper.writeValueAsString(Map.of(
                    "messaging_product", "whatsapp",
                    "to", to,
                    "type", "text",
                    "text", Map.of("body", text)
            ));

            post.setEntity(new StringEntity(payload, StandardCharsets.UTF_8));
            client.execute(post);
            System.out.println("Replied to " + to + ": " + text);
        } catch (Exception e) {
            System.err.println("Failed to send message: " + e.getMessage());
        }
    }
}